<!--
Licensed by AT&T under 'Software Development Kit Tools Agreement.' 2012
TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION: http://developer.att.com/sdk_agreement/
Copyright 2011 AT&T Intellectual Property. All rights reserved. http://developer.att.com
For more information contact developer.support@att.com
-->

<?php
    $api_key = "";
    $secret_key = "";
    $FQDN = "https://api.att.com";
    $oauth_file = "cmsoauthtoken.php";
    $scope = "CMS";
    $callcontrol_file = "callcontrolscript.php";
    $number = "";
?>
